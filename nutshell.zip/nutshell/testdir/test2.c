#include <stdio.h>

int main(void) {
	printf("test2 executable\n");
	printf("Yo YO!!!!!\n");
	return 0;
}

